---
layout: post
title:  "Workshops, Facilities, and Infrastructure"
date:   2010-04-08 10:00:00 +0100
categories: semester
---

# Workshops, Facilities, and Infrastructure

### Rapid Prototyping Werkstatt
[[File:Rapid Prototyping Werkstatt.jpg|frameless]]
[[File:Rapid Prototyping Werkstatt-2.jpg|frameless]]


### 3D Drucker Werkstatt
[[File:3D Drucker Werkstatt.jpg|frameless]]


### Druckerraum
[[File:Druckerraum.jpg|frameless]]


### Modellbau Werkstatt
[[File:Modellbau Werkstatt.jpg|frameless]]
[[File:Modellbau Werkstatt-2.jpg|frameless]]
[[File:Modellbau Werkstattleiter.jpg|frameless]]


### Metall Werkstatt
[[File:Metall Werkstatt.jpg|frameless]]
[[File:Metall Werkstatt-2.jpg|frameless]]


### Kunstguss und Metall Werkstatt
[[File:Kunstguss und Metall Werkstatt.jpg|frameless]]
[[File:Kunstguss und Metall Werkstatt-2.jpg|frameless]]


### Keramik Werkstatt
[[File:Keramik Werkstatt.jpg|frameless]]
[[File:Keramik Werkstatt-2.jpg|frameless]]


### Lackierkabine
[[File:Lackierkabine.jpg|frameless]]


### Mode Werkstatt
[[File:Mode Werkstatt.jpg|frameless]]


### Hausmeister
[[File:Hausmeister.jpg|frameless]]


### Bibliothek
[[File:Bibliothek.jpg|frameless]]
[[File:Bibliothek-2.jpg|frameless]]
[[File:Bibliothek-3.jpg|frameless]]


