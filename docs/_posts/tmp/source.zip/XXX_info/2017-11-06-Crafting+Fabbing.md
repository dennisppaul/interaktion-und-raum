---
layout: post
title:  "Crafting+Fabbing"
date:   2017-11-06 10:00:00 +0100
categories: semester
---

# Crafting+Fabbing


## Spaces

### Bremen

* [FabLab Bremen e.V.](http://www.fablab-bremen.org), FB3, Uni Bremen
* [LRAUM](http://craftspace.de/space/lraum-metallwerkstatt/) Metallwerkstatt von Christian Lamour, Überseestadt
* [F+S Zerspanungstechnik](http://www.fs-zerspanung.de) CNC-Drehen und CNC-Fräsen




