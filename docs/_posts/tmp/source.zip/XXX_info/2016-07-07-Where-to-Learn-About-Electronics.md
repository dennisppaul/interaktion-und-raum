---
layout: post
title:  "Where to Learn About Electronics"
date:   2016-07-07 10:00:00 +0100
categories: semester
---

# Where to Learn About Electronics

* [http://www.tigoe.net/pcomp/ Tom Igoe's Physical Computing]
* [http://www.physical-computing.de//blog/ Physical Computing Blog]
* [http://www.arduino.cc/ Arduino][http://arduino.cc/en/Tutorial/HomePage][http://www.arduino.cc/playground/]
* [http://electricalwhat.com/ Explains schematics]

[[Category:Electronics]]


