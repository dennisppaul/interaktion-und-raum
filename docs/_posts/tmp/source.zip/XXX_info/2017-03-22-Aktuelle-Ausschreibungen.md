---
layout: post
title:  "Aktuelle Ausschreibungen"
date:   2017-03-22 10:00:00 +0100
categories: semester
---

# Aktuelle Ausschreibungen

## Aktuell
{{#iDisplay:http://dennisppaul.de/awardsandcalls/public.php|100%|50%}}

-----

## Andere Sammlungen
Also check out these collections …

* [http://www.udk-berlin.de/sites/institut_kunst/content/wettbewerbe/index_ger.html Bildende Kunst @ UdK Berlin]
* [http://www.hfbk-hamburg.de/de/aktuell/ausschreibungen HFBK Hamburg]
* [http://www.hbk-bs.de/studiengaenge/kommunikationsdesign/aktuelles/wettbewerbe-stipendien/index.php HbK Braunschweig]
* [http://kunst.khm.de/archiv-ausschreibungen KHM Köln]
* [http://www.ufg.ac.at/Wettbewerbe-Ausschreibungen.1233.0.html UfG Linz]
* [http://fk.hfk-bremen.de/ Freie Kunst HfK Bremen]
* [[Congresses, Festivals and Awards]]

Might also be interested in [[Grants and Scholarships]]

---

/* Aktuell */
