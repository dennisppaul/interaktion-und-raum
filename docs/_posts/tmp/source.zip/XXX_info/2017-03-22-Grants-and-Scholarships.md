---
layout: post
title:  "Grants and Scholarships"
date:   2017-03-22 10:00:00 +0100
categories: semester
---

# Grants and Scholarships

## Collection
{{#iDisplay:http://dennisppaul.de/grantsandscholarships/public.php|100%|25%}}



## Others

* [Freie Kunst @ HfK Bremen](http://fk.hfk-bremen.de) -- Liste von Ausschreibungen
* [Bildende Kunst @ UdK Berlin](http://www.udk-berlin.de/sites/institut_kunst/content/stiftungen___stipendien/index_ger.html) -- Liste von Stiftungen und Stipendien

## Resources not specific to Art + Design

* [Wer vergibt Stipendien fürs Studium?](http://www.sueddeutsche.de/bildung/foerderung-fuer-begabte-und-beduerftige-wer-vergibt-stipendien-fuers-studium-1.1284701) -- article at [sueddeutsche.de](http://www.sueddeutsche.de)
* [Kann ich mich im Master noch für ein Stipendium bewerben?](http://www.sueddeutsche.de/bildung/foerderung-nach-dem-bachelor-kann-ich-mich-im-master-noch-fuer-ein-stipendium-bewerben-1.1285549) -- article at [sueddeutsche.de](http://www.sueddeutsche.de)
* [master and more - stipendien](http://www.master-and-more.de/finanzierung/stipendien.html)
* [mystipendium.de](http://www.mystipendium.de/)


---

/* Collection */
