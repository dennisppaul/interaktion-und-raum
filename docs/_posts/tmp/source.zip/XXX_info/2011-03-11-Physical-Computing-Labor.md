---
layout: post
title:  "Physical Computing Labor"
date:   2011-03-11 10:00:00 +0100
categories: semester
---

# Physical Computing Labor

The Physical Computing Labor is an accumulation of the following components

* [[Physical Computing Library]]
* [[The Laser Cutter]]

[[Category:Electronics]]


