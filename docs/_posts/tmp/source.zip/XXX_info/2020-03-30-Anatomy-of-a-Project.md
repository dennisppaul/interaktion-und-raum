---
layout: post
title:  "Anatomy of a Project"
date:   2020-03-30 10:00:00 +0100
categories: semester
---

# Anatomy of a Project

<!--<gdoc id# "1KO0LWY7qnL7WfSk3w-uFx4fTtnnRAUHVGj5_shPJDmk" />-->

This document is available as a public google document at [http://goo.gl/J3az7A](http://goo.gl/J3az7A)


