---
layout: post
title:  "Job Offers"
date:   2019-10-08 10:00:00 +0100
categories: semester
---

# Job Offers


- job offers on our slack channel [#jobs](https://digitalmedia-bremen.slack.com/messages/C5WTKT3UN)
- a list of [job offers](http://www.creativeapplications.net/job-board) at [Creative Applications](http://www.creativeapplications.net/)
- a small and only occasionally ( 2017?!? ) updated list of [job offers](http://dennisppaul.de/joboffers/public.php)



