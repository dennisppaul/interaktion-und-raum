---
layout: post
title:  "Individual Critique"
date:   2021-03-19 10:00:00 +0100
categories: semester
---

# Individual Critique


If you are interested in an individual critique, whether related to your current projects or on a more general note, please reserve a slot [here](http://dm-hb.de/icdpp). you can also contact me via [mail](mailto:d.paul@hfk-bremen.de).



