---
layout: post
title:  "Sketches and Programs"
date:   2019-07-30 10:00:00 +0100
categories: semester
---

# Sketches and Programs

##  @Git 
* https://github.com/d3p/hfk-bremen
* https://github.com/organizations/HfK-Bremen
* https://github.com/digitalmediabremen

---

/* @Git */
